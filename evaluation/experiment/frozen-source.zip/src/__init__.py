"""AIMScribe baseline recommender components."""
